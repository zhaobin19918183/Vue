<template>
    <div>
        课程页面
    </div>
</template>

<script>
    export default{
        name:"course",
        data(){
            return{

            }
        }
    }
</script>

<style scoped>
    
</style>
<template>
    <div>
        HelloWorld
    </div>
</template>

<script>
    export default{
        name:"helloWorld",
        data(){
            return{

            }
        }
    }
</script>

<style scoped>
    
</style>
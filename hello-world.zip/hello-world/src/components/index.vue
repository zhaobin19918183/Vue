<template>
    <div>
        主页1
           <router-link to="/HelloWorld">课程</router-link>
    </div>
</template>

<script>
    export default{
        name:"index",
        data(){
            return{

            }
        }
    }
</script>

<style scoped>
    
</style>